'use strict';


var mongoose = require('mongoose'),
  Dish = mongoose.model('Dishes'),
  Place = mongoose.model('Places');

exports.list_all_dishes = function (req, res) {
    Dish.find({}, function (err, task) {
        if (err)
            res.send(err);
        res.json(task);
    });
};

exports.create_a_dish = function (req, res) {
    var new_task = new Dish(req.body);
    new_task.save(function (err, task) {
        if (err)
            res.send(err);
        res.json(task);
    });
};


exports.read_a_dish = function (req, res) {
    Dish.findById(req.params.dishId, function (err, dish) {
        if (err)
            res.send(err);
        res.json(dish);
    });
};


exports.update_a_dish = function (req, res) {
    Dish.findOneAndUpdate({ _id: req.params.dishId }, req.body, { new: true }, function (err, dish) {
        if (err)
            res.send(err);
        res.json(dish);
    });
};


exports.delete_a_dish = function (req, res) {
    Dish.remove({
        _id: req.params.dishId
    }, function (err, dish) {
        if (err)
            res.send(err);
        res.json({ message: 'Dish successfully deleted' });
    });
};

exports.read_dish_places = function (req, res) {
    Dish.findById(req.params.dishId, function (err, dish) {
        if (err)
            res.send(err);

        var asd = [];
        var temp;

        for (var i = 0; i < dish.places.length; i++){
            Place.findById(dish.places[i]._id, function (err,place) { 
                temp = place;
            })
            asd[i] = {
                "dishplace": dish.places[i],
                "placeinfo": temp
            };
        }
        res.json(asd);
    });
};

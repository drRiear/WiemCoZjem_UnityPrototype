'use strict';
module.exports = function (app) {

    var todoList = require('../controllers/MainController');
    var places = require('../controllers/PlacesController');
    var dishes = require('../controllers/DishesController');

    app.route('/specifics')
      .get(todoList.list_all_tasks)
      .post(todoList.create_a_task);

    app.route('/specifics/:taskId')
      .get(todoList.read_a_task)
      .put(todoList.update_a_task)
      .delete(todoList.delete_a_task);

    app.route('/places')
      .get(places.list_all_places)
      .post(places.create_a_place);

    app.route('/places/:placeId')
      .get(places.read_a_place)
      .put(places.update_a_place)
      .delete(places.delete_a_place);

    app.route('/dishes')
      .get(dishes.list_all_dishes)
      .post(dishes.create_a_dish);

    app.route('/dishes/:dishId')
      .get(dishes.read_a_dish)
      .put(dishes.update_a_dish)
      .delete(dishes.delete_a_dish);

    app.route('/dish_places/:dishId')
    .get(dishes.read_dish_places);

};
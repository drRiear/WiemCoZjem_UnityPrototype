'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var PlaceSchema = new Schema({
    items: [{
        name: String,
        description: String,
        hours: {
            monday: String,
            thuesday: String,
            wednesday: String,
            thursday: String,
            friday: String,
            saturday: String,
            sunday: String
        },
        stars: [Number]
    }]
});

module.exports = mongoose.model('Places', PlaceSchema);

/*
PUT
http://localhost:3000/places/5a2f192b2951be209c98b915

{
	"items":[
		{
			"name": "ergergerfsf",
		    "description": "asfgasfas gfasfas fdasfda sd asd a",
		    "hours":{
	            "monday": "12:30-14:20",
	            "thuesday": "12:30-14:20",
	            "wednesday": "12:30-14:20",
	            "thursday": "12:30-14:20",
	            "friday": "12:30-14:20",
	            "saturday": "12:30-14:20",
	            "sunday": "12:30-14:20"
        	},
        	"stars":["1","2","1"]
		},
		{
			"name": "asd",
		    "description": "sgdgsdf sdf asdf asd fasdfasa",
		    "hours":{
	            "monday": "12:30-14:20",
	            "thuesday": "12:30-14:20",
	            "wednesday": "12:30-14:20",
	            "thursday": "12:30-14:20",
	            "friday": "12:30-14:20",
	            "saturday": "12:30-14:20",
	            "sunday": "12:30-14:20"
        	},
        	"stars":["5","4","2"]
		}
	]
}
*/
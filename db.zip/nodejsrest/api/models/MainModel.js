'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var TaskSchema = new Schema({
    items: [{
        placeID: String,
        dishID: String,
        price: String,
        stars: [Number]
    }]
});

module.exports = mongoose.model('Tasks', TaskSchema);

/*
PUT
http://localhost:3000/specifics/5a2f1c37f9db1506ac0fefc9

{
	"items":[
		{
			"placeID": "5a2f19826d135818fc2369dd",
        	"dishID": "5a2f17cab8de6900a44b9623",
        	"price": "12,50",
        	"stars": [1,2,3,4]
		},
		{
			"placeID": "5a2f19826d135818fc2369dc",
        	"dishID": "5a2f17cab8de6900a44b9623",
        	"price": "12,00",
        	"stars": [1,2,3,4]
		}
	]
}
*/
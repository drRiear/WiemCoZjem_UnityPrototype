'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var DishSchema = new Schema({
    items: [{
        name: String,
        alergens: [String],
        ingredients: [String],
        vege: Boolean
    }]
});

module.exports = mongoose.model('Dishes', DishSchema);

/*
PUT
http://localhost:3000/dishes/5a2aeba20c97b2337c43d163

{
	"items":[
		{
			"name": "ergergerfsf",
		    "vege": "true",
		    "alergens":["asd","asdgaefda","asgsedf"],
		    "ingredients":["asddfsa","asdafs"]
		},
        {
			"name": "asd",
		    "vege": "true",
		    "alergens":["asd","asdgaefda","asgsedf"],
		    "ingredients":["asddfsa","asdafs"]
		},
        ...
	]
}
*/